#!/bin/bash

CONFIG_FILE="observer.conf"
LOG_FILE="observer.log"

log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

if [ ! -f "$CONFIG_FILE" ]; then
    log_message "ERROR: Config file $CONFIG_FILE not found"
    exit 1
fi

log_message "Starting script monitoring"

# Чтение файла конфигурации
while IFS= read -r line; do
    # Пропускаем комментарии и пустые строки
    if [[ "$line" =~ ^# ]] || [[ -z "$line" ]]; then
        continue
    fi

    script_path=$(echo "$line" | xargs)  # Убираем пробелы

    if [ ! -f "$script_path" ]; then
        log_message "ERROR: Script $script_path not found"
        continue
    fi

    script_name=$(basename "$script_path")
    # Проверяем запущен ли процесс
    if pgrep -f "$script_name" > /dev/null; then
        log_message "Script $script_name is already running"
    else
        log_message "Starting script: $script_path"
        nohup "$script_path" > /dev/null 2>&1 &
        log_message "Script $script_name started with PID $!"
    fi
done < "$CONFIG_FILE"

log_message "Script monitoring completed"
