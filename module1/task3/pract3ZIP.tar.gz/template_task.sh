#!/bin/bash

# Получение имени скрипта
SCRIPT_NAME=$(basename "$0")

# ФАйл для вывода
REPORT_FILE="report_template_task.log"

PID=$$

# Запись информации о скрипте
echo "[$PID] $(date '+%Y-%m-%d %H:%M:%S') Скрипт запущен" >> "$REPORT_FILE"



# Проверка имени скрипта
if [ "$SCRIPT_NAME" = "template_task.sh" ]; then
    echo "я бригадир, сам не работаю"
    exit 1
fi

# ФАйл для вывода
REPORT_FILE="report_template_task.log"

# Генерирация случайного числа
RANDOM_SECONDS=$(( RANDOM % 1771 + 30 ))

sleep $RANDOM_SECONDS

# Вычисление минут работы
MINUTES=$(( (RANDOM_SECONDS + 59) / 60 ))

echo "[$PID] $(date '+%Y-%m-%d %H:%M:%S') Скрипт завершился, работал $MINUTES минут" >> "$REPORT_FILE"
